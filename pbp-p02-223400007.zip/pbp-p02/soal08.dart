List<String> tampilanKeranjang({
  required List<String> barang,
  required Map<String, int> harga,
  bool sedangMemuat = false,
  String? galat,
}) {

  if (sedangMemuat) {
    return ['Sedang memuat keranjang...'];
  }

  if (galat != null) {
    return [
      'Galat: $galat',
      'Silakan coba lagi.',
    ];
  }

  if (barang.isEmpty) {
    return [
      'Keranjang kosong.',
      'Silakan tambahkan barang.',
    ];
  }

  final List<String> hasil = [];
  int total = 0;

  for (String namaBarang in barang) {
    final int hargaBarang = harga[namaBarang] ?? 0;

    hasil.add('$namaBarang: $hargaBarang');
    total += hargaBarang;
  }

  hasil.add('Total: $total');

  return hasil;
}

void main() {
  final Map<String, int> harga = {
    'kopi': 8000,
    'teh': 5000,
    'roti': 7000,
  };

  print(tampilanKeranjang(
    barang: ['kopi'],
    harga: harga,
    sedangMemuat: true,
  ));
  print(tampilanKeranjang(
    barang: ['kopi'],
    harga: harga,
    galat: 'Gagal mengambil data',
  ));
  print(tampilanKeranjang(
    barang: [],
    harga: harga,
  ));
  print(tampilanKeranjang(
    barang: ['kopi', 'teh', 'sate'],
    harga: harga,
  ));
}