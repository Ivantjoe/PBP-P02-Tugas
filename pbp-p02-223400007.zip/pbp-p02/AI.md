Laporan Penggunaan AI

1. Alat yang Digunakan
Dalam mengerjakan Tugas Terstruktur 1 mata kuliah Pemrograman Berbasis Platform, saya menggunakan ChatGPT sebagai alat bantu.

2. Bagian yang Dibantu
ChatGPT saya gunakan untuk membantu beberapa hal, yaitu:

1. memahami instruksi dari soal 1 sampai soal 10;
2. memahami penggunaan tipe data, final, null safety, fungsi, parameter bernama, List, dan Map dalam Dart;
3. membuat contoh kode awal untuk setiap soal;
4. mengecek logika program dan mencari kemungkinan kesalahan pada kode;
5. memahami cara menangani kondisi kosong, nilai null, dan error;
6. memastikan setiap soal memiliki pengujian yang dilakukan di dalam main()

3. Perubahan yang Saya Lakukan
Kode yang diberikan oleh ChatGPT tidak langsung saya gunakan begitu saja. Saya pelajari terlebih dahulu, kemudian saya sesuaikan dengan ketentuan tugas, materi yang dipelajari pada Pertemuan 2, serta kebutuhan pengujian pada setiap soal

4. Catatan
Saya menggunakan AI hanya sebagai alat bantu untuk memahami materi dan mengerjakan tugas. Setelah itu, kode tetap saya periksa, jalankan, pahami, dan sesuaikan kembali sebelum dikumpulkan