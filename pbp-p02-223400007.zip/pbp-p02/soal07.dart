String? periksaNim(String nim, {int tahunSekarang = 2026}) {
  if (nim.length != 7) {
    return 'Panjang NIM harus tujuh angka';
  }

  for (int i = 0; i < nim.length; i++) {
    if (nim.codeUnitAt(i) < 48 || nim.codeUnitAt(i) > 57) {
      return 'NIM tidak boleh mengandung huruf';
    }
  }
  final int tahunMasuk = int.parse(nim.substring(0, 4));

  if (tahunMasuk < 2015 || tahunMasuk > tahunSekarang) {
    return 'Empat angka pertama bukan tahun masuk yang masuk akal';
  }
  return null;
}

void main() {
  print(periksaNim('2026123'));
  print(periksaNim('202712'));
  print(periksaNim('232A125'));
  print(periksaNim('2016456'));
}
