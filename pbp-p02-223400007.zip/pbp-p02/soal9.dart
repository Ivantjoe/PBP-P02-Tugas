const Map<String, int> katalog = {
  'kopi': 5000,
  'teh': 4000,
  'roti': 8000,
};

Map<String, Object> tanganiPermintaan(
  Map<String, String> kueri,
) {
  final String? barang = kueri['barang'];
  if (barang == null || barang.isEmpty) {
    return {
      'status': 400,
      'pesan': 'Parameter barang harus diisi',
    };
  }

  final String? jumlahText = kueri['jumlah'];
  int jumlah = 1;
  if (jumlahText != null) {
    final int? hasilParse = int.tryParse(jumlahText);

    if (hasilParse == null) {
      return {
        'status': 400,
        'pesan': 'Parameter jumlah harus berupa nilai: $jumlahText',
      };
    }

    jumlah = hasilParse;
  }

  if (jumlah < 1) {
    return {
      'status': 400,
      'pesan': 'Parameter jumlah kurang dari 1',
    };
  }
  final int? harga = katalog[barang];

  if (harga == null) {
    return {
      'status': 404,
      'pesan': 'Barang tidak ditemukan: $barang',
    };
  }

  return {
    'status': 200,
    'barang': barang,
    'jumlah': jumlah,
    'total': harga * jumlah,
  };
}

void main() {
  print(tanganiPermintaan({
  }));

  print(tanganiPermintaan({
    'barang': 'kopi',
    'jumlah': 'abc',
  }));

  print(tanganiPermintaan({
    'barang': 'kopi',
    'jumlah': '0',
  }));

  print(tanganiPermintaan({
    'barang': 'sate',
    'jumlah': '2',
  }));

  print(tanganiPermintaan({
    'barang': 'kopi',
    'jumlah': '3',
  }));

  print(tanganiPermintaan({
    'barang': 'teh',
  }));
}
