Map<String, int> bagiTagihan(
  int total,
  List<String> peserta,
  Map<String, int> diskonPersen,
) {
  final Map<String, int> hasil = {};
  if (peserta.isEmpty) {
    return hasil;
  }
  int totalBobot = 0;

  for (String nama in peserta) {
    final int diskon = diskonPersen[nama] ?? 0;
    final int bobot = 100 - diskon;
    totalBobot += bobot;
  }
  int totalDibagi = 0;

  for (String nama in peserta) {
    final int diskon = diskonPersen[nama] ?? 0;
    final int bobot = 100 - diskon;
    final int bagian = total * bobot ~/ totalBobot;
    hasil[nama] = bagian;
    totalDibagi += bagian;
  }

  final int sisa = total - totalDibagi;
  if (sisa != 0) {
    final String pesertaPertama = peserta.first;
    hasil[pesertaPertama] =
        (hasil[pesertaPertama] ?? 0) + sisa;
  }
  return hasil;
}

void main() {
  final int total = 6000000;
  final List<String> peserta = [
    'Andi',
    'Budi',
    'Cindy',
  ];

  final Map<String, int> diskon = {
    'Andi': 10,
    'Budi': 20,
  };

  final Map<String, int> hasil = bagiTagihan(
    total,
    peserta,
    diskon,
  );
  int jumlahBayaran = 0;
  hasil.forEach((nama, bayaran) {
    print('$nama membayar: $bayaran');
    jumlahBayaran += bayaran;
  });
  print('');
  print('Jumlah seluruh bayaran: $jumlahBayaran');
  print('Total sebenarnya       : $total');
  print('Apakah jumlah sama?    : ${jumlahBayaran == total}');
}